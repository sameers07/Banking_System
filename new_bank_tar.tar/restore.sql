--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.10 (Ubuntu 14.10-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.10 (Ubuntu 14.10-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE bank;
--
-- Name: bank; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE bank WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_IN';


ALTER DATABASE bank OWNER TO postgres;

\connect bank

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: create_another_account(integer, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.create_another_account(IN cid integer, IN acc_type character varying)
    LANGUAGE plpgsql
    AS $$
begin
	if(acc_type = any(select account.account_type from customer,depositor,account where customer.customer_id=cid and customer.customer_id=depositor.customer_id and depositor.account_id=account.account_id)) then 
		raise notice 'account type already exisits';
	else 
		insert into account(account_id,account_type,branch_code)
		values (((select max(account_id) from account)+1),acc_type,(select branch_code from branch where branch_city=(select city_name from customer where customer_id=c_id)));
		insert into depositor(customer_id,account_id,access_date) 
		values((select customer_id from customer where customer_id=cid),(select max(account_id) from account),current_date);
	end if;
end;$$;


ALTER PROCEDURE public.create_another_account(IN cid integer, IN acc_type character varying) OWNER TO postgres;

--
-- Name: create_loan(integer, numeric, character varying, integer, numeric); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.create_loan(IN cid integer, IN l_amount numeric, IN l_type character varying, IN l_duration integer, IN int_rate numeric)
    LANGUAGE plpgsql
    AS $$
begin
	insert into loan(loan_id,loan_amount,loan_type,loan_duration_months,interest_rate,branch_code)
	values((select max(loan_id) from loan)+1,l_amount,l_type,l_duration,int_rate,
		   (select branch_code from branch where branch_city=(select city_name from customer where customer_id=cid)),current_date);
	insert into borrower(customer_id,loan_id) 
	values (cid,(select max(loan_id) from loan));
	insert into payment(payment_id,payment_amount,payment_date,loan_id)
	values((select max(payment_id) from payment)+1,0,current_date,(select max(loan_id) from loan));
end;
$$;


ALTER PROCEDURE public.create_loan(IN cid integer, IN l_amount numeric, IN l_type character varying, IN l_duration integer, IN int_rate numeric) OWNER TO postgres;

--
-- Name: create_new_account(character varying, date, character varying, character varying, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.create_new_account(IN fullname character varying, IN dob date, IN c_name character varying, IN s_name character varying, IN p_no character varying, IN acc_type character varying)
    LANGUAGE plpgsql
    AS $$
begin
	insert into customer(customer_id,customer_name,birth_date,city_name,state_name,phone_number)
	values((select max(customer_id) from customer)+1,fullname,dob,c_name,s_name,p_no);
	insert into account(account_id,account_type,branch_code)
	values (((select max(account_id) from account)+1),acc_type,(select branch_code from branch where branch_city=c_name));
	insert into depositor(customer_id,account_id,access_date) 
	values ((select max(customer_id) from customer),(select max(account_id) from account),current_date);
end;$$;


ALTER PROCEDURE public.create_new_account(IN fullname character varying, IN dob date, IN c_name character varying, IN s_name character varying, IN p_no character varying, IN acc_type character varying) OWNER TO postgres;

--
-- Name: deposit(numeric, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.deposit(IN amount_deposited numeric, IN aid integer)
    LANGUAGE plpgsql
    AS $$
begin
	update account
	set balance = balance + amount_deposited
	where account_id = aid;
	update depositor
	set access_date = current_date
	where account_id = aid;
end; $$;


ALTER PROCEDURE public.deposit(IN amount_deposited numeric, IN aid integer) OWNER TO postgres;

--
-- Name: get_payment(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_payment() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare pay_amount int;
begin
	pay_amount = ((select loan_amount from loan where loan_id=(select max(loan_id) from loan))*((select interest_rate from loan where loan_id=(select max(loan_id) from loan))/(12*100))*power(1+((select interest_rate from loan where loan_id=(select max(loan_id) from loan))/(12*100)),(select loan_duration_months from loan where loan_id=(select max(loan_id) from loan)))/(power(1+((select interest_rate from loan where loan_id=(select max(loan_id) from loan))/(12*100)),(select loan_duration_months from loan where loan_id=(select max(loan_id) from loan)))-1));
	update loan 
	set monthly_payment=pay_amount where loan_id=(select max(loan_id) from loan);	
	return new;
end;
$$;


ALTER FUNCTION public.get_payment() OWNER TO postgres;

--
-- Name: give_bal(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.give_bal() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
	if((select account_type from account where account_id=new.account_id)= 'Zero Balance Account') then
		update account 
		set balance=0
		where account_id=new.account_id;
		return new;
	else
		update account 
		set balance=5000
		where account_id=new.account_id;
		return new;
	end if;
end;$$;


ALTER FUNCTION public.give_bal() OWNER TO postgres;

--
-- Name: no_of_accounts(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.no_of_accounts(cid integer, OUT ans integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
begin
	select count(*) into ans from depositor 
	group by(customer_id) having customer_id=cid;
end;$$;


ALTER FUNCTION public.no_of_accounts(cid integer, OUT ans integer) OWNER TO postgres;

--
-- Name: show_balance(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.show_balance(cid integer) RETURNS TABLE(account_id integer, account_type character varying, balance numeric)
    LANGUAGE plpgsql
    AS $$
begin
	return query
	select Account.account_id, Account.account_type, Account.balance from Customer, Depositor, Account
	where Customer.customer_id = cid 
	and Customer.customer_id = Depositor.customer_id
	and Depositor.account_id = Account.account_id;
end;$$;


ALTER FUNCTION public.show_balance(cid integer) OWNER TO postgres;

--
-- Name: transfer(integer, integer, numeric); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.transfer(IN sid integer, IN rid integer, IN amount numeric)
    LANGUAGE plpgsql
    AS $$
begin 
    if((select balance from account where account_id=sid ) < amount) then
		raise notice 'insufficient balance in sender account';
    else
    	update account 
		set balance=balance-amount where account_id=sid;
    	update account 
		set balance=balance+amount where account_id=rid;
		update depositor 
		set access_date=current_date where account_id=sid;
    end if;
end;$$;


ALTER PROCEDURE public.transfer(IN sid integer, IN rid integer, IN amount numeric) OWNER TO postgres;

--
-- Name: withdraw(numeric, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.withdraw(IN amount numeric, IN aid integer)
    LANGUAGE plpgsql
    AS $$
begin
	if((select balance from account where account_id=aid) < amount) then 
		raise notice 'insufficient balance in account';
	else
		update account 
		set balance=balance-amount where account_id=aid;
		update depositor 
		set access_date=current_date where account_id=aid;
	end if;
end;$$;


ALTER PROCEDURE public.withdraw(IN amount numeric, IN aid integer) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account (
    account_id integer NOT NULL,
    account_type character varying(50) NOT NULL,
    balance numeric,
    last_updated timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    branch_code integer
);


ALTER TABLE public.account OWNER TO postgres;

--
-- Name: borrower; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.borrower (
    customer_id integer NOT NULL,
    loan_id integer NOT NULL
);


ALTER TABLE public.borrower OWNER TO postgres;

--
-- Name: branch; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.branch (
    branch_code integer NOT NULL,
    branch_name character varying(50) NOT NULL,
    branch_city character varying(50) NOT NULL
);


ALTER TABLE public.branch OWNER TO postgres;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    customer_id integer NOT NULL,
    customer_name character varying(50) NOT NULL,
    birth_date date NOT NULL,
    city_name character varying(50) NOT NULL,
    state_name character varying(50) NOT NULL,
    phone_number character varying(12) NOT NULL
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: customer_details; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.customer_details AS
SELECT
    NULL::character varying(50) AS customer_name,
    NULL::date AS birth_date,
    NULL::text AS address,
    NULL::text AS all_account_types;


ALTER TABLE public.customer_details OWNER TO postgres;

--
-- Name: loan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.loan (
    loan_id integer NOT NULL,
    loan_amount numeric NOT NULL,
    loan_type character varying(50) NOT NULL,
    loan_duration_months integer NOT NULL,
    interest_rate numeric NOT NULL,
    monthly_payment numeric NOT NULL,
    branch_code integer,
    CONSTRAINT loan_loan_amount_check CHECK ((loan_amount > (0)::numeric))
);


ALTER TABLE public.loan OWNER TO postgres;

--
-- Name: customer_loan; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.customer_loan AS
 SELECT customer.customer_id,
    customer.customer_name,
    loan.loan_id,
    loan.loan_amount
   FROM ((public.customer
     JOIN public.borrower ON ((customer.customer_id = borrower.customer_id)))
     JOIN public.loan ON ((borrower.loan_id = loan.loan_id)));


ALTER TABLE public.customer_loan OWNER TO postgres;

--
-- Name: depositor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.depositor (
    customer_id integer NOT NULL,
    account_id integer NOT NULL,
    access_date date NOT NULL
);


ALTER TABLE public.depositor OWNER TO postgres;

--
-- Name: employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee (
    employee_id integer NOT NULL,
    employee_name character varying(50) NOT NULL,
    employee_role character varying(50) NOT NULL,
    salary numeric NOT NULL,
    mobile_number character varying(12) NOT NULL,
    branch_code integer,
    CONSTRAINT employee_salary_check CHECK ((salary > (0)::numeric))
);


ALTER TABLE public.employee OWNER TO postgres;

--
-- Name: payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment (
    payment_id integer NOT NULL,
    payment_amount numeric NOT NULL,
    payment_date date NOT NULL,
    loan_id integer
);


ALTER TABLE public.payment OWNER TO postgres;

--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account (account_id, account_type, balance, last_updated, branch_code) FROM stdin;
\.
COPY public.account (account_id, account_type, balance, last_updated, branch_code) FROM '$$PATH$$/3432.dat';

--
-- Data for Name: borrower; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.borrower (customer_id, loan_id) FROM stdin;
\.
COPY public.borrower (customer_id, loan_id) FROM '$$PATH$$/3431.dat';

--
-- Data for Name: branch; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.branch (branch_code, branch_name, branch_city) FROM stdin;
\.
COPY public.branch (branch_code, branch_name, branch_city) FROM '$$PATH$$/3426.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (customer_id, customer_name, birth_date, city_name, state_name, phone_number) FROM stdin;
\.
COPY public.customer (customer_id, customer_name, birth_date, city_name, state_name, phone_number) FROM '$$PATH$$/3428.dat';

--
-- Data for Name: depositor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.depositor (customer_id, account_id, access_date) FROM stdin;
\.
COPY public.depositor (customer_id, account_id, access_date) FROM '$$PATH$$/3433.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee (employee_id, employee_name, employee_role, salary, mobile_number, branch_code) FROM stdin;
\.
COPY public.employee (employee_id, employee_name, employee_role, salary, mobile_number, branch_code) FROM '$$PATH$$/3429.dat';

--
-- Data for Name: loan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.loan (loan_id, loan_amount, loan_type, loan_duration_months, interest_rate, monthly_payment, branch_code) FROM stdin;
\.
COPY public.loan (loan_id, loan_amount, loan_type, loan_duration_months, interest_rate, monthly_payment, branch_code) FROM '$$PATH$$/3427.dat';

--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment (payment_id, payment_amount, payment_date, loan_id) FROM stdin;
\.
COPY public.payment (payment_id, payment_amount, payment_date, loan_id) FROM '$$PATH$$/3430.dat';

--
-- Name: account account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (account_id);


--
-- Name: borrower borrower_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.borrower
    ADD CONSTRAINT borrower_pkey PRIMARY KEY (customer_id, loan_id);


--
-- Name: branch branch_branch_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.branch
    ADD CONSTRAINT branch_branch_name_key UNIQUE (branch_name);


--
-- Name: branch branch_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.branch
    ADD CONSTRAINT branch_pkey PRIMARY KEY (branch_code);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (customer_id);


--
-- Name: depositor depositor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.depositor
    ADD CONSTRAINT depositor_pkey PRIMARY KEY (customer_id, account_id);


--
-- Name: employee employee_employee_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_employee_name_key UNIQUE (employee_name);


--
-- Name: employee employee_mobile_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_mobile_number_key UNIQUE (mobile_number);


--
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (employee_id);


--
-- Name: loan loan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loan
    ADD CONSTRAINT loan_pkey PRIMARY KEY (loan_id);


--
-- Name: payment payment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_pkey PRIMARY KEY (payment_id);


--
-- Name: customer_details _RETURN; Type: RULE; Schema: public; Owner: postgres
--

CREATE OR REPLACE VIEW public.customer_details AS
 SELECT customer.customer_name,
    customer.birth_date,
    (((customer.city_name)::text || ', '::text) || (customer.state_name)::text) AS address,
    string_agg((account.account_type)::text, ', '::text) AS all_account_types
   FROM ((public.customer
     JOIN public.depositor ON ((customer.customer_id = depositor.customer_id)))
     JOIN public.account ON ((depositor.account_id = account.account_id)))
  GROUP BY customer.customer_id;


--
-- Name: loan get_monthly_payment; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER get_monthly_payment AFTER INSERT ON public.loan FOR EACH ROW EXECUTE FUNCTION public.get_payment();


--
-- Name: account give_cal; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER give_cal AFTER INSERT ON public.account FOR EACH ROW EXECUTE FUNCTION public.give_bal();


--
-- Name: account account_branch_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_branch_code_fkey FOREIGN KEY (branch_code) REFERENCES public.branch(branch_code);


--
-- Name: borrower borrower_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.borrower
    ADD CONSTRAINT borrower_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);


--
-- Name: borrower borrower_loan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.borrower
    ADD CONSTRAINT borrower_loan_id_fkey FOREIGN KEY (loan_id) REFERENCES public.loan(loan_id);


--
-- Name: depositor depositor_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.depositor
    ADD CONSTRAINT depositor_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.account(account_id);


--
-- Name: depositor depositor_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.depositor
    ADD CONSTRAINT depositor_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);


--
-- Name: employee employee_branch_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_branch_code_fkey FOREIGN KEY (branch_code) REFERENCES public.branch(branch_code);


--
-- Name: loan loan_branch_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loan
    ADD CONSTRAINT loan_branch_code_fkey FOREIGN KEY (branch_code) REFERENCES public.branch(branch_code);


--
-- Name: payment payment_loan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_loan_id_fkey FOREIGN KEY (loan_id) REFERENCES public.loan(loan_id);


--
-- PostgreSQL database dump complete
--

